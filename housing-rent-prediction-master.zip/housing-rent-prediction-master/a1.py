
import pandas as pd  # data processing
import numpy as np  # working with arrays
import matplotlib.pyplot as plt  # visualization
import seaborn as sb  # visualization
from termcolor import colored as cl  # text customization

from sklearn.model_selection import train_test_split  # data split

from sklearn.linear_model import LinearRegression  # OLS algorithm
from sklearn.linear_model import Ridge  # Ridge algorithm
from sklearn.linear_model import Lasso  # Lasso algorithm
from sklearn.linear_model import BayesianRidge  # Bayesian algorithm
from sklearn.linear_model import ElasticNet  # ElasticNet algorithm
from sklearn.ensemble import AdaBoostRegressor

from sklearn.metrics import explained_variance_score as evs  # evaluation metric
from sklearn.metrics import r2_score as r2  # evaluation metric

sb.set_style('whitegrid')
plt.rcParams['figure.figsize'] = (20, 10)

# IMPORTING DATA

df = pd.read_csv('_All_Cities_Cleaned.csv')
#df.set_index('Id', inplace=True)

df.head(5)
# EDA

df.dropna(inplace=True)

print(df.isnull().sum())

df.describe()

print(df.dtypes)

df['area'] = pd.to_numeric(df['area'], errors='coerce')
df['area'] = df['area'].astype('int64')

print(df.dtypes)

# DATA VISUALIZATION

# 1. Heatmap

sb.heatmap(df.corr(), annot=True, cmap='magma')

plt.savefig('heatmap.png')
#plt.show()

def scatter_df(y_var):
    scatter_df = df.drop(y_var,axis=1)
    i = df.columns
    print(y_var)

    plot1 = sb.scatterplot(x=i[0], y=y_var, data=df,
                           color='orange', edgecolor='b', s=150)
    plt.title('{} / Sale Price'.format(i[0]), fontsize=16)
    plt.xlabel('{}'.format(i[0]), fontsize=14)
    plt.ylabel('Sale Price', fontsize=14)
    plt.xticks(fontsize=12)
    plt.yticks(fontsize=12)
    plt.savefig('scatter1.png')
    #p#lt.show()

    plot2 = sb.scatterplot(x=i[1], y=y_var, data=df,color='yellow', edgecolor='b', s=150)
    plt.title('{} / Sale Price'.format(i[1]), fontsize=16)
    plt.xlabel('{}'.format(i[1]), fontsize=14)
    plt.ylabel('Sale Price', fontsize=14)
    plt.xticks(fontsize=12)
    plt.yticks(fontsize=12)
    plt.savefig('scatter2.png')
    #p#lt.show()

    plot3 = sb.scatterplot(x=i[2],y= y_var, data=df,color='aquamarine', edgecolor='b', s=150)
    plt.title('{} / Sale Price'.format(i[2]), fontsize=16)
    plt.xlabel('{}'.format(i[2]), fontsize=14)
    plt.ylabel('Sale Price', fontsize=14)
    plt.xticks(fontsize=12)
    plt.yticks(fontsize=12)
    plt.savefig('scatter3.png')
    #p#lt.show()

    plot4 = sb.scatterplot(x=i[3], y=y_var, data=df,
                           color='deepskyblue', edgecolor='b', s=150)
    plt.title('{} / Sale Price'.format(i[3]), fontsize=16)
    plt.xlabel('{}'.format(i[3]), fontsize=14)
    plt.ylabel('Sale Price', fontsize=14)
    plt.xticks(fontsize=12)
    plt.yticks(fontsize=12)
    plt.savefig('scatter4.png')
    #p#lt.show()

    plot5 = sb.scatterplot(x=i[4], y=y_var, data=df,
                           color='crimson', edgecolor='white', s=150)
    plt.title('{} / Sale Price'.format(i[4]), fontsize=16)
    plt.xlabel('{}'.format(i[4]), fontsize=14)
    plt.ylabel('Sale Price', fontsize=14)
    plt.xticks(fontsize=12)
    plt.yticks(fontsize=12)
    plt.savefig('scatter5.png')
    #p#lt.show()

    plot6 = sb.scatterplot(x=i[5], y=y_var, data=df,
                           color='darkviolet', edgecolor='white', s=150)
    plt.title('{} / Sale Price'.format(i[5]), fontsize=16)
    plt.xlabel('{}'.format(i[5]), fontsize=14)
    plt.ylabel('Sale Price', fontsize=14)
    plt.xticks(fontsize=12)
    plt.yticks(fontsize=12)
    plt.savefig('scatter6.png')
    #p#lt.show()

    plot7 = sb.scatterplot(x=i[6], y=y_var, data=df,
                           color='khaki', edgecolor='b', s=150)
    plt.title('{} / Sale Price'.format(i[6]), fontsize=16)
    plt.xlabel('{}'.format(i[6]), fontsize=14)
    plt.ylabel('Sale Price', fontsize=14)
    plt.xticks(fontsize=12)
    plt.yticks(fontsize=12)
    plt.savefig('scatter7.png')
    #p#lt.show()

    plot8 = sb.scatterplot(x=i[7], y=y_var, data=df,
                           color='gold', edgecolor='b', s=150)
    plt.title('{} / Sale Price'.format(i[7]), fontsize=16)
    plt.xlabel('{}'.format(i[7]), fontsize=14)
    plt.ylabel('Sale Price', fontsize=14)
    plt.xticks(fontsize=12)
    plt.yticks(fontsize=12)
    plt.savefig('scatter8.png')
    #p#lt.show()

    plot9 = sb.scatterplot(x=i[8], y=y_var, data=df,
                           color='r', edgecolor='b', s=150)
    plt.title('{} / Sale Price'.format(i[8]), fontsize=16)
    plt.xlabel('{}'.format(i[8]), fontsize=14)
    plt.ylabel('Sale Price', fontsize=14)
    plt.xticks(fontsize=12)
    plt.yticks(fontsize=12)
    plt.savefig('scatter9.png')
    #p#lt.show()

    plot10 = sb.scatterplot(x=i[9], y=y_var, data=df,
                            color='deeppink', edgecolor='b', s=150)
    plt.title('{} / Sale Price'.format(i[9]), fontsize=16)
    plt.xlabel('{}'.format(i[9]), fontsize=14)
    plt.ylabel('Sale Price', fontsize=14)
    plt.xticks(fontsize=12)
    plt.yticks(fontsize=12)
    plt.savefig('scatter10.png')
    #p#lt.show()


scatter_df('price')

# 3. Distribution plot

sb.distplot(df['price'], color='r')
plt.title('Sale Price Distribution', fontsize=16)
plt.xlabel('Sale Price', fontsize=14)
plt.ylabel('Frequency', fontsize=14)
plt.xticks(fontsize=12)
plt.yticks(fontsize=12)

plt.savefig('distplot.png')
#plt.show()


# DATA SPLIT

X_var = df[['area']].values
y_var = df['price'].values

X_train, X_test, y_train, y_test = train_test_split(
    X_var, y_var, test_size=0.2, random_state=0)

print('X_train samples : ', X_train[0:5])
print('X_test samples : ', X_test[0:5])
print('y_train samples : ', y_train[0:5])
print('y_test samples : ', y_test[0:5])

# MODELLING

# 1. OLS

ols = LinearRegression()
ols.fit(X_train, y_train)
ols_yhat = ols.predict(X_test)

# 2. Ridge

ridge = Ridge(alpha=0.5)
ridge.fit(X_train, y_train)
ridge_yhat = ridge.predict(X_test)

# 3. Lasso

lasso = Lasso(alpha=0.01)
lasso.fit(X_train, y_train)
lasso_yhat = lasso.predict(X_test)
print(lasso_yhat)
# 4. Bayesian

bayesian = BayesianRidge()
bayesian.fit(X_train, y_train)
bayesian_yhat = bayesian.predict(X_test)
print(bayesian_yhat)
# 5. ElasticNet

en = ElasticNet(alpha=0.01)
en.fit(X_train, y_train)
en_yhat = en.predict(X_test)
# 6. Adaboost
ad = AdaBoostRegressor(random_state=0, n_estimators=100)
ad.fit(X_train, y_train)
ad_yhat = ad.predict(X_test)

# EVALUATION

# 1. Explained Variance Score

print('EXPLAINED VARIANCE SCORE:')
print('-------------------------------------------------------------------------------')
a=('Explained Variance Score of Multiple Regression model is {}'.format(
    evs(y_test, ols_yhat)))

a1=(format(evs(y_test, ols_yhat)))
print('Explained Variance Score of Multiple Regression model is {}'.format(a1))
print('-------------------------------------------------------------------------------')
b=('Explained Variance Score of Ridge model is {}'.format(
    evs(y_test, ridge_yhat)))
b1=(format(
    evs(y_test, ridge_yhat)))
print(b1)
print('-------------------------------------------------------------------------------')
c=('Explained Variance Score of Lasso model is {}'.format(
    evs(y_test, lasso_yhat)))
c1= (format(evs(y_test, lasso_yhat)))
print(c)
print('-------------------------------------------------------------------------------')
d1=(format(evs(y_test, bayesian_yhat)))
print(('Explained Variance Score of Bayesian model is {}:',d1))


print('-------------------------------------------------------------------------------')
e1=(format(evs(y_test, en_yhat)))
print(('Explained Variance Score of ElasticNet is {}', e1))
print('-------------------------------------------------------------------------------')

f1=(format(evs(y_test, ad_yhat)))
print(('Explained Variance Score of Adaboost is {}', f1))
print('-------------------------------------------------------------------------------')
# R-squared

print('R-SQUARED:')
print('-------------------------------------------------------------------------------')
a2=(format(r2(y_test, ols_yhat)))
print('R-Squared of OLS model is {}', a2)
print('-------------------------------------------------------------------------------')
b2= (format(r2(y_test, ridge_yhat)))
print('R-Squared of Ridge model is {}',b2)
print('-------------------------------------------------------------------------------')
c2=(format(r2(y_test, lasso_yhat)))
print('R-Squared of Lasso model is {}', c2)
print('-------------------------------------------------------------------------------')
d2=(format(r2(y_test,bayesian_yhat)))
print('R-Squared of Bayesian model is {}', d2)
print('-------------------------------------------------------------------------------')
e2=(format(r2(y_test, en_yhat)))
print('R-Squared of ElasticNet is ', e2)
print('-------------------------------------------------------------------------------')
f2=((r2(y_test, ad_yhat)))
print('R-Squared of Adaboost is {}', f2)
print('-------------------------------------------------------------------------------')

print(type(f2))

import pandas as pd
import numpy as np
print(type(f2))

a1 = np.float64(a1)
a1 = pd.Series(np.array([a1]))
a1 = a1.astype(float)
b1 = np.float64(b1)
b1 = pd.Series(np.array([b1]))
b1 = b1.astype(float)
c1 = np.float64(c1)
c1 = pd.Series(np.array([c1]))
c1 = c1.astype(float)

d1 = np.float64(d1)
d1 = pd.Series(np.array([d1]))
d1 = d1.astype(float)
e1 = np.float64(e1)
e1 = pd.Series(np.array([e1]))
e1 = e1.astype(float)
f1 = np.float64(f1)
f1 = pd.Series(np.array([f1]))
f1 = f1.astype(float)

a2 = np.float64(a2)
a2 = pd.Series(np.array([a2]))

b2 = np.float64(b2)
b2 = pd.Series(np.array([b2]))

c2 = np.float64(c2)
c2 = pd.Series(np.array([c2]))

d2 = np.float64(d2)
d2 = pd.Series(np.array([d2]))

e2 = np.float64(e2)
e2 = pd.Series(np.array([e2]))

f2 = np.float64(f2)
f2 = pd.Series(np.array([f2]))
import matplotlib.pyplot as plt

data = pd.Series([a1,b1,c1,d1,e1,f1])

print(type(data))
#data = data.astype(float)

# Plot a bar graph
data.plot.bar()

# Display the graph
plt.show()
