from math import sqrt
from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OrdinalEncoder
import numpy as np  # linear algebra
import pandas as pd  # data processing, CSV file I/O (e.g. pd.read_csv)
import os
from termcolor import colored as cl  # text customization
from sklearn.linear_model import LinearRegression  # OLS algorithm
from sklearn.linear_model import Ridge  # Ridge algorithm
from sklearn.linear_model import Lasso  # Lasso algorithm
from sklearn.linear_model import BayesianRidge  # Bayesian algorithm
from sklearn.linear_model import ElasticNet  # ElasticNet algorithm
from sklearn.ensemble import AdaBoostRegressor

from sklearn.metrics import explained_variance_score as evs  # evaluation metric
from sklearn.metrics import r2_score as r2  # evaluation metric
for dirname, _, filenames in os.walk('Dataset'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
# Load the data
df = pd.read_csv("Delhi.csv")
# Splitting datasets into X and y
LABEL_COLUMNS = ["Price"]
y = df[LABEL_COLUMNS]
X = df.drop(LABEL_COLUMNS, axis=1)
for col in X.columns:
    print("{}: {}".format(col, X[col].unique()))
INSUFFICIENT_COLUMNS = ["Wifi", "Wardrobe"]

# Filter out the relevant columns
FEATURE_COLUMNS = ["Area", "Location", "No. of Bedrooms", "Resale", "LiftAvailable", "Hospital", "CarParking",
                   "PowerBackup", "24X7Security", "School", "SportsFacility", "ShoppingMall", "SwimmingPool", "Gymnasium", "MaintenanceStaff"]
for col in FEATURE_COLUMNS[4:]:
    d = dict()
    for key in X[col].unique():
        d[key] = len([data for data in X[col] if data == key])
    print("{}: {}".format(col, d))
FEATURE_COLUMNS = FEATURE_COLUMNS[:4]
X = X[FEATURE_COLUMNS]
X.shape
CATEGORICAL_COLUMNS = []
for col in X.columns:
    d_type = X[col].dtype
    if d_type == "object":
        CATEGORICAL_COLUMNS.append(col)

print(X.info())
print()
print("Categorical columns:", CATEGORICAL_COLUMNS)
unique_locs = X["Location"].unique()
print(unique_locs)
print(len(unique_locs))

ord = OrdinalEncoder()
# for col in CATEGORICAL_COLUMNS:
X[CATEGORICAL_COLUMNS] = ord.fit_transform(X[CATEGORICAL_COLUMNS])

X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=1)
# Creating the model
model = LinearRegression()

# Training the model
model.fit(X_train, y_train)

# Validating the model
preds = model.predict(X_test)
mae = mean_absolute_error(y_test, preds)
rmse = sqrt(mean_squared_error(y_test, preds))

# print("Mean Absolute Error: {}".format(mae))
# print("Root Mean Squared Error: {}".format(rmse))
# MODELLING

# 1. OLS

ols = LinearRegression()
ols.fit(X_train, y_train)
ols_yhat = ols.predict(X_test)

# 2. Ridge

ridge = Ridge(alpha=0.5)
ridge.fit(X_train, y_train)
ridge_yhat = ridge.predict(X_test)

# 3. Lasso

lasso = Lasso(alpha=0.01)
lasso.fit(X_train, y_train)
lasso_yhat = lasso.predict(X_test)

# 4. Bayesian

bayesian = BayesianRidge()
bayesian.fit(X_train, y_train)
bayesian_yhat = bayesian.predict(X_test)

# 5. ElasticNet

en = ElasticNet(alpha=0.01)
en.fit(X_train, y_train)
en_yhat = en.predict(X_test)
# 6. Adaboost
ad = AdaBoostRegressor(random_state=0, n_estimators=100)
ad.fit(X_train, y_train)
ad_yhat = ad.predict(X_test)

# EVALUATION

# 1. Explained Variance Score

print(cl('EXPLAINED VARIANCE SCORE:', attrs=['bold']))
print('-------------------------------------------------------------------------------')
print(cl('Explained Variance Score of Multiple Regression model is {}'.format(
    evs(y_test, ols_yhat)), attrs=['bold']))
print('-------------------------------------------------------------------------------')
print(cl('Explained Variance Score of Ridge model is {}'.format(
    evs(y_test, ridge_yhat)), attrs=['bold']))
print('-------------------------------------------------------------------------------')
print(cl('Explained Variance Score of Lasso model is {}'.format(
    evs(y_test, lasso_yhat)), attrs=['bold']))
print('-------------------------------------------------------------------------------')
print(cl('Explained Variance Score of Bayesian model is {}'.format(
    evs(y_test, bayesian_yhat)), attrs=['bold']))
print('-------------------------------------------------------------------------------')
print(cl('Explained Variance Score of ElasticNet is {}'.format(
    evs(y_test, en_yhat)), attrs=['bold']))
print('-------------------------------------------------------------------------------')
print(cl('Explained Variance Score of Adaboost is {}'.format(
    evs(y_test, ad_yhat)), attrs=['bold']))
print('-------------------------------------------------------------------------------')
# R-squared

print(cl('R-SQUARED:', attrs=['bold']))
print('-------------------------------------------------------------------------------')
print(
    cl('R-Squared of OLS model is {}'.format(r2(y_test, ols_yhat)), attrs=['bold']))
print('-------------------------------------------------------------------------------')
print(cl('R-Squared of Ridge model is {}'.format(r2(y_test, ridge_yhat)),
      attrs=['bold']))
print('-------------------------------------------------------------------------------')
print(cl('R-Squared of Lasso model is {}'.format(r2(y_test, lasso_yhat)),
      attrs=['bold']))
print('-------------------------------------------------------------------------------')
print(cl('R-Squared of Bayesian model is {}'.format(r2(y_test,
      bayesian_yhat)), attrs=['bold']))
print('-------------------------------------------------------------------------------')
print(
    cl('R-Squared of ElasticNet is {}'.format(r2(y_test, en_yhat)), attrs=['bold']))
print('-------------------------------------------------------------------------------')
print(
    cl('R-Squared of Adaboost is {}'.format(r2(y_test, ad_yhat)), attrs=['bold']))
print('-------------------------------------------------------------------------------')
