import numpy as np #for handling arrays 
import pandas as pd #for handling dataframes 
# for building models 
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor,GradientBoostingRegressor,AdaBoostRegressor
from sklearn.tree import DecisionTreeRegressor
from xgboost import XGBRegressor
# for hyperparameter tuning 
from sklearn.model_selection import train_test_split, GridSearchCV
# for model evaluation 
from sklearn.metrics import mean_absolute_error, r2_score
# for visualzing results 
import matplotlib.pyplot as plt 
# to interact with hardware and save the final model 
import os
import joblib
# to display dataframes 
from IPython.display import display
# use the style available in seaborn library 
plt.style.use('seaborn')

# create some constants 
RESULTS_SAVE_PATH = 'Results/'
MODEL_SAVE_PATH = 'Objects/Models/'
EVALUATION_FIGSIZE = (16,6)
EVALUATION_NROWS = 1
EVALUATION_NCOLS = 2
CITIES = ['AHEMDABAD','BANGALORE','CHENNAI','DELHI','HYDERABAD','KOLKATA','MUMBAI','PUNE']
TEST_SIZE = 0.3
RANDOM_STATE = 42
PREPROCESSED_FILE_PATH = 'preprocessed/'

# Fetch the data and store in the dictionary 
df_dict = dict(zip(CITIES, [pd.read_csv(os.path.join(PREPROCESSED_FILE_PATH, f'{city}.csv')) for city in CITIES]))
# close the connection 
# rename the columns to ensure uniformity
cols = cols = ['SELLER TYPE','BEDROOM','LAYOUT TYPE','PROPERTY TYPE','LOCALITY','PRICE','AREA','FURNISH TYPE','BATHROOM']

for city, df in df_dict.items():
    df.columns = cols

# store X and y for each city in dictionary
X_dict = dict(zip(CITIES,[df.drop(['PRICE'],axis=1) for df in df_dict.values()]))
y_dict = dict(zip(CITIES,[df['PRICE'] for df in df_dict.values()]))

# Create dictionaries for X_train, y_train, X_test and y_test 
X_train_dict = {}
X_test_dict = {}
y_train_dict = {}
y_test_dict = {}

for city in CITIES:
    # Subset X and y for each city
    X = X_dict[city]
    y = y_dict[city]
    # Perform train test split
    X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=TEST_SIZE, random_state=RANDOM_STATE)
    # Store values in the dictionary for training models
    X_train_dict[city] = X_train
    X_test_dict[city] = X_test
    y_train_dict[city] = y_train
    y_test_dict[city] = y_test

# create a helper function
def summarize_model(model):
    model_r2_train_dict = {} #create a dictionary for r2 score of train set
    model_r2_test_dict = {} #create a dictionary for r2 score of test set
    model_mae_train_dict = {} #create a dictionary for mae of train set 
    model_mae_test_dict = {} #create a dictionary for mae of test set
    model_dict = {} #create a dictionary of models 
    for city in CITIES: #loop through the cities 
        model.fit(X_train_dict[city],y_train_dict[city]) #fit the model 
        model_dict[city] = model #store the model for that city in model dict
        model_train_preds = model.predict(X_train_dict[city]) #predict for train set 
        model_test_preds = model.predict(X_test_dict[city]) #predict for test set 
        model_r2_train_dict[city] = r2_score(y_true=y_train_dict[city], y_pred=model_train_preds) #calculate r2 for train set 
        model_r2_test_dict[city] = r2_score(y_true=y_test_dict[city], y_pred=model_test_preds) #calculate r2 for test set 
        model_mae_train_dict[city] = mean_absolute_error(y_true=y_train_dict[city],y_pred=model_train_preds) #calcaulte mae for train set
        model_mae_test_dict[city] = mean_absolute_error(y_true=y_test_dict[city], y_pred=model_test_preds) #calculate mae for test set 

    # store the metrics in a dictionary 
    metrics_dict = {
        'train r2':model_r2_train_dict,
        'test r2':model_r2_test_dict,
        'train mae':model_mae_train_dict,
        'test mae':model_mae_test_dict
    }
    display(pd.DataFrame(metrics_dict))
    return model_dict, metrics_dict #return model and metrics 

# Linear Regression 
lr_dict, lr_metrics = summarize_model(LinearRegression())

# Decision tree regression 
dt_dict, dt_metrics = summarize_model(DecisionTreeRegressor())

# Random forest regression  
rf_dict, rf_metrics = summarize_model(RandomForestRegressor())

# Adaboost Regression
adaboost_dict, adaboost_metrics = summarize_model(AdaBoostRegressor())

# Gradient boosting regression 
gb_dict, gb_metrics = summarize_model(GradientBoostingRegressor())

# XGBoost Regression 
xgb_dict, xgb_metrics = summarize_model(XGBRegressor(objective='reg:squarederror'))

# create dictionaries for visualization 
model_dict = {
    'LR':lr_dict,
    'DT':dt_dict,
    'RF':rf_dict,
    'ADA':adaboost_dict,
    'GB':gb_dict,
    'XGB':xgb_dict
}
model_metrics = {
    'LR':lr_metrics,
    'DT':dt_metrics,
    'RF':rf_metrics,
    'ADA':adaboost_metrics,
    'GB':gb_metrics,
    'XGB':xgb_metrics
}

# Create dictionaries for metrics for all models 
train_r2 = {}
test_r2 = {}
train_mae = {}
test_mae = {}

for model, metrics_dict in model_metrics.items():
    train_r2[model] = metrics_dict['train r2']
    test_r2[model] = metrics_dict['test r2']
    train_mae[model] = metrics_dict['train mae']
    test_mae[model] = metrics_dict['test mae']


# Convert them to dataframes 
train_r2 = pd.DataFrame(train_r2)
test_r2 = pd.DataFrame(test_r2)
train_mae = pd.DataFrame(train_mae)
test_mae = pd.DataFrame(test_mae)

# Change the column names for identification 
train_r2.columns = [col+'_train_r2' for col in train_r2.columns]
test_r2.columns = [col+'_test_r2' for col in test_r2.columns] 
train_mae.columns = [col+'_train_mae' for col in train_mae.columns]
test_mae.columns = [col+'_test_mae' for col in test_mae.columns]

# Create dataframe for plotting r2 score 
plot_r2 = pd.DataFrame()
for c1, c2 in zip(train_r2.columns, test_r2.columns):
    plot_r2[c1] = train_r2[c1]
    plot_r2[c2] = test_r2[c2]

# create dataframe for plotting mae 
plot_mae = pd.DataFrame()
for c1,c2 in zip(train_mae.columns, test_mae.columns):
    plot_mae[c1] = train_mae[c1]
    plot_mae[c2] = test_mae[c2]

# transpose the dataframes for easy plotting 
plot_r2 = plot_r2.T
plot_mae = plot_mae.T

# Reshape cities to plot better 
cities_plot = np.array(CITIES).reshape(4,2)

fig, ax = plt.subplots(figsize=(16,16),nrows=4,ncols=2) #create a 4*2 figure 
for i in range(4): #loop through rows 
    for j in range(2): #loop through columns 
        plot_r2[cities_plot[i,j]].plot(kind='bar',ax=ax[i,j]) #plot the column  
        ax[i,j].set_title(cities_plot[i,j]) #set title 
plt.tight_layout() #tight layout for avoiding overlap 
if not os.path.exists(RESULTS_SAVE_PATH): #check if path exists 
    os.makedirs(RESULTS_SAVE_PATH) #if not, create the path 
plt.savefig(os.path.join(RESULTS_SAVE_PATH, 'all_models_r2.png')) #save the results 
plt.show() #show the plot 

fig, ax = plt.subplots(figsize=(16,16),nrows=4,ncols=2) #create 4*2 figure 
for i in range(4): #loop through rows 
    for j in range(2): #loop through columns 
        plot_mae[cities_plot[i,j]].plot(kind='bar',ax=ax[i,j]) #plot the column 
        ax[i,j].set_title(cities_plot[i,j]) #set the title 
plt.tight_layout() #tight layout to avoud overlap 
plt.savefig(os.path.join(RESULTS_SAVE_PATH, 'all_moedls_mae.png')) #save the figure 
plt.show() #show the figure 

# hyperparameter tuning 
param_tuning = {
        'learning_rate': [0.001,0.01,0.1],
        'max_depth': [3, 5, 7],
        'n_estimators' : [100, 200,300],
    }

# perform cross validation
xgb_validated_dict = {} #create a dictionary for validated xgboost model 
for city, model in xgb_dict.items(): #loop though  existing xgboost model 
    xgb_validated = GridSearchCV(model, param_tuning, cv=3, n_jobs=-1, verbose=2, scoring='neg_mean_squared_error') #perform cross validation
    xgb_validated.fit(X_train_dict[city], y_train_dict[city]) #fit the validated model 
    xgb_validated_dict[city] = xgb_validated #save the model in the dictionary 

# create a dictionary for metrics 
xgb_validated_metrics = {}
train_r2_dict = {}
test_r2_dict = {}
train_mae_dict = {}
test_mae_dict = {}
for city, model in xgb_validated_dict.items(): #loop through validated xgboost models 
    train_preds = model.predict(X_train_dict[city]) #predict on train set 
    test_preds = model.predict(X_test_dict[city]) #predict on test set 
    train_r2 = r2_score(y_true=y_train_dict[city],y_pred=train_preds) #calculate r2 on train set 
    test_r2 = r2_score(y_true=y_test_dict[city],y_pred=test_preds) #calculate r2 on test set 
    train_mae = mean_absolute_error(y_true=y_train_dict[city], y_pred=train_preds) #calculate mae on train set 
    test_mae = mean_absolute_error(y_true=y_test_dict[city],y_pred=test_preds) #calculate mae on test set 
    # store metrics in respective dictionaries 
    train_r2_dict[city] = train_r2 
    test_r2_dict[city] = test_r2
    train_mae_dict[city] = train_mae
    test_mae_dict[city] = test_mae
# create dictionary for storing metrics 
xgb_validated_metrics = {
    'train r2':train_r2_dict,
    'test r2':test_r2_dict,
    'train mae': train_mae_dict,
    'test mae':test_mae_dict
}

# convert metrics of xgboost and validated model to dataframe 
xgb_metrics_df = pd.DataFrame(xgb_metrics)
xgb_validated_metrics_df = pd.DataFrame(xgb_validated_metrics)

# rename columns for easy interpretation 
xgb_metrics_df.columns = [col + '_xgb' for col in xgb_metrics_df.columns]
xgb_validated_metrics_df.columns = [col + '_xgb_val' for col in xgb_validated_metrics_df.columns]

# create a final metrics dataframe for plotting 
final_metrics_df = pd.DataFrame()
for c1, c2 in zip(xgb_metrics_df.columns, xgb_validated_metrics_df.columns):
    final_metrics_df[c1] = xgb_metrics_df[c1]
    final_metrics_df[c2] = xgb_validated_metrics_df[c2]

fig, ax = plt.subplots(figsize=(20,20),nrows=2, ncols=2) #create a 2*2 figure 
final_metrics_df[['train r2_xgb', 'train r2_xgb_val']].plot(kind='bar',ax=ax[0,0],title='TRAIN R2 SCORE') #plot train r2 for both models 
final_metrics_df[['test r2_xgb', 'test r2_xgb_val']].plot(kind='bar',ax=ax[0,1], title='TEST R2 SCORE') #plot test r2 for both models 
final_metrics_df[['train mae_xgb', 'train mae_xgb_val']].plot(kind='bar', ax=ax[1,0], title='TRAIN MAE') #plot train mae for both models 
final_metrics_df[['test mae_xgb', 'test mae_xgb_val']].plot(kind='bar', ax=ax[1,1],title='TEST MAE') #plot test mae for both models 
plt.tight_layout() #tight layout to avoid overlap 
plt.savefig(os.path.join(RESULTS_SAVE_PATH, 'hyperparameter_tuning.png')) #save the figure 
plt.show() #show the figure 

# save the models after fitting them on entire dataset 
for city in CITIES:
    if not os.path.exists(MODEL_SAVE_PATH):
        os.makedirs(MODEL_SAVE_PATH)
    xgb_model = XGBRegressor(objective='reg:squarederror')
    xgb_model.fit(X_dict[city], y_dict[city])
    joblib.dump(xgb_model, os.path.join(MODEL_SAVE_PATH, f'{city}_model.pkl'))

